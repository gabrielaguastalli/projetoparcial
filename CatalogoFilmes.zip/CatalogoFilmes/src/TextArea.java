import javax.swing.JTextArea;

public class TextArea extends JTextArea {

	private static final long serialVersionUID = 1L;
	
	private int linhas = 1;
	private int colunas = 20;
	
	public TextArea() {
		super();
		init();
	}
	
	public TextArea(int center) {
		super();
		init();
	}

	private void init() {
		this.setRows(linhas);
		this.setColumns(colunas);
		this.setBorder(BordaFactory.criar());
	}

}
