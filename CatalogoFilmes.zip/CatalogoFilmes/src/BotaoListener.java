import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

public class BotaoListener implements ActionListener {

	private TextField tituloTextField; 
	
	public BotaoListener(TextField tituloTextField) {
		this.tituloTextField = tituloTextField;
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JOptionPane.showMessageDialog(null, "Salvo com sucesso");
	}

	
}
