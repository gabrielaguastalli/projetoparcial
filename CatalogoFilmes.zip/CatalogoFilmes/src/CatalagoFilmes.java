import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class CatalagoFilmes {

	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Erro ao carregar");
		}
		
		JFrame frame = new JFrame("Catalogo de filmes");
		

		//TextArea tituloTextArea = new TextArea();
		TextField tituloTextField = new TextField();
		//JPanel cadastro = new JPanel(new GridLayout(13,20));
		//TextField nameTextField = new TextField();

	
		JPanel cadastro = new JPanel();
			
		cadastro.setLayout(new FlowLayout());
		
		String[] generos = {"","A��o", "Com�dia", "Romance", "Suspense", "Terror"};
	
	//	janela.add(janela, BorderLayout.CENTER);
		
		
		
		
	
		JButton botao = new JButton("Salvar");
		botao.addActionListener(new BotaoListener(tituloTextField));
		
		JButton botao2 = new JButton("Cancelar");
		
		JPanel lista = new JPanel();
		
		
		
		
		JTabbedPane abas = new JTabbedPane();
		abas.add("Cadastro", cadastro);
		abas.add("Lista", lista);
		
		List<String> ListaDeOpcoes = List.of(
				"Netflix",
				"Prime",
				"Disney Plus",
				"Globo Play");
		RadioGroup group = new RadioGroup(ListaDeOpcoes);
		
		cadastro.setLayout(new FlowLayout(FlowLayout.LEADING,10,20));
		
		
		cadastro.add(new Label("T�tulo     "));
		
		cadastro.add(new TextArea(JLabel.LEFT));
		cadastro.add(new Label("                                                  ")); // gambiarra que funciona
		cadastro.add(new Label("Sinopse"));
		cadastro.add(new TextArea(JLabel.LEFT));
		cadastro.add(new Label("                                            "));
		cadastro.add(new Label("G�nero "));
		cadastro.add(new JComboBox<String>(generos));
		cadastro.add(new Label("                                                            "));
		cadastro.add(new Label("Onde assitir"));
		cadastro.add(group);
		cadastro.add(new Label("                 "));
		cadastro.add(new JCheckBox("Assistido"), BorderLayout.SOUTH);
		cadastro.add(new Label("             Avalia��o"));
		cadastro.add(new StarRater(5, 0));
		cadastro.add(new Label("                                                                  "));
		cadastro.add(botao);
		cadastro.add(botao2);
		
		//cadastro.add(new JLabel(new ImageIcon("src/StarWars.png")));
		
		
		
		
		lista.setLayout(new FlowLayout());
		
		lista.add(new Label("Lista de Filmes Assistidos"));
		lista.add(new TextField());
		lista.add(new TextArea());
		
		frame.add(abas);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.setSize(500,350);
		
	}


	
 
	
}
